package com.example.bettercalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    protected lateinit var display: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.input)

        display.setOnClickListener(View.OnClickListener {
            fun onClick(v: View)
            {
                if(getString(R.string.display).equals(display.text.toString()))
                {
                    display.setText("")
                }
            }
        })
    }
    fun zeroBTN(view: View) {

    }
    fun oneBTN(view: View)
    {

    }
    fun twoBTN(view: View)
    {

    }
    fun threeBTN(view: View)
    {

    }
    fun fourBTN(view: View)
    {

    }
    fun fiveBTN(view: View)
    {

    }
    fun sixBTN(view: View)
    {

    }
    fun sevenBTN(view: View)
    {

    }
    fun eightBTN(view: View)
    {

    }
    fun nineBTN(view: View)
    {

    }
    fun comaBTN(view: View)
    {

    }
    fun equalsBTN(view: View)
    {

    }
    fun backspaceBTN(view: View)
    {

    }
    fun divideBTN(view: View)
    {

    }
    fun multBTN(view: View)
    {

    }
    fun minusBTN(view: View)
    {

    }
    fun plusBTN(view: View)
    {

    }
    fun rightBTN(view: View)
    {

    }
}